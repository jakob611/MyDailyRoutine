package com.example.mydailyroutine.core.designsystem.sound

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext
import com.example.mydailyroutine.R

val LocalRoutineSounds = staticCompositionLocalOf<RoutineSounds> { error("RoutineSounds provider is required") }

/**
 * The app's audio vocabulary, drawn from the brand's fifteen-sound interface pack (`sound_*`)
 * and paired with the haptic vocabulary in [com.example.mydailyroutine.core.designsystem.haptics.RoutineHaptics].
 * (The ten-sound click pack in `clicks.zip` stays in the repository reserved for a later pass.)
 *
 * Sound is the louder sibling of a vibration, so it has to earn its place even more carefully:
 * haptics answer every step and tick, but a blip on each of those would turn the app into a toy.
 * The sounds therefore sit only on the moments that already carry a *semantic* haptic — an outcome
 * the reader should notice without looking — and fire together with it, so ear and palm tell the
 * same story at the same instant:
 *
 * * **addToDay** — interface pack 12, on the editor's „Dodaj v moj dan“ save with the success
 *   haptic: the day accepted a new block.
 * * **confirm** — interface pack 2, on the other committed changes (edits, tasks, imports) and on
 *   a completed block, with the success haptic.
 * * **reject** — interface pack 3, when something is deleted or refused, with the error haptic.
 * * **open** — interface pack 8, when the „Dodaj blok“ pill or another sheet opens, with the press
 *   haptic.
 * * **topAction** — interface pack 12, on the four top-bar icon buttons (načrtovanje, naloge,
 *   cilji, nastavitve), with the press haptic — the same voice as addToDay, so the two "add"
 *   gestures answer alike.
 * * **select** — interface pack 1, on the Dan / Teden / Mesec / Leto segmented tabs, with the
 *   selection haptic: the quietest sound, on the most frequent control.
 *
 * All six assets are mastered to the same loudness band (RMS ≈ −17.5 dB, peaks tamed per crest)
 * so no control is louder than another on the phone's volume scale. The pool plays on the
 * **media** stream at full scale: the hardware keys the reader reaches for are exactly the ones
 * that control these sounds. The app's own preference is the master switch; [preview] lets the
 * settings screen prove audibility the moment the switch flips on.
 */
@Stable
class RoutineSounds internal constructor(context: Context, private val enabled: State<Boolean>) {
    private val loaded = mutableSetOf<Int>()
    private val pool = SoundPool.Builder()
        .setMaxStreams(MAX_CONCURRENT)
        .setAudioAttributes(feedbackAudio)
        .build()
        .also { pool -> pool.setOnLoadCompleteListener { _, sampleId, status -> if (status == 0) loaded += sampleId } }

    private val addToDayId = pool.load(context, R.raw.sound_12, 1)
    private val confirmId = pool.load(context, R.raw.sound_2, 1)
    private val rejectId = pool.load(context, R.raw.sound_3, 1)
    private val openId = pool.load(context, R.raw.sound_8, 1)
    private val topActionId = addToDayId
    private val selectId = pool.load(context, R.raw.sound_1, 1)

    /** „Dodaj v moj dan“: the day accepted a new block. Interface pack 12, success haptic. */
    fun addToDay() = play(addToDayId)

    /** A change was committed or a block completed. Interface pack 2, success haptic. */
    fun confirm() = play(confirmId)

    /** Something was deleted or refused. Interface pack 3, error haptic. */
    fun reject() = play(rejectId)

    /** The „Dodaj blok“ pill or another sheet opened. Interface pack 8, press haptic. */
    fun open() = play(openId)

    /** A top-bar icon button was pressed. Interface pack 12, press haptic. */
    fun topAction() = play(topActionId)

    /** The scale tabs changed: Dan / Teden / Mesec / Leto. Interface pack 1, selection haptic. */
    fun select() = play(selectId)

    /**
     * Plays the confirm sound regardless of the preference, for the settings screen: flipping the
     * switch on should answer with the sound itself, before the preference write has propagated.
     */
    fun preview() = play(confirmId, force = true)

    private fun play(sampleId: Int, force: Boolean = false) {
        if (!force && !enabled.value) return
        if (!loaded.contains(sampleId)) return
        pool.play(sampleId, VOLUME, VOLUME, PRIORITY, 0, RATE)
    }

    internal fun release() = pool.release()

    private companion object {
        /** Full scale: the system media volume the reader sets is the loudness knob. */
        const val VOLUME = 1f
        const val MAX_CONCURRENT = 4
        const val PRIORITY = 1
        const val RATE = 1f

        // Media usage on purpose: it is the one stream whose volume the hardware keys control on
        // every device, so "turn it up" actually turns these sounds up.
        val feedbackAudio = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
    }
}

@Composable
fun rememberRoutineSounds(enabled: Boolean): RoutineSounds {
    val context = LocalContext.current.applicationContext
    val currentEnabled = rememberUpdatedState(enabled)
    val sounds = remember(context) { RoutineSounds(context, currentEnabled) }
    DisposableEffect(sounds) { onDispose { sounds.release() } }
    return sounds
}
