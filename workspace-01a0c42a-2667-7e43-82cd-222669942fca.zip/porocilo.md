# Poročilo – PR #10 (veja `arena/01a0bfd5-mydailyroutine`)

## Stanje (21. 9.)
PR #10 je merge-an (`master` = `c38514c`), zato `master` trenutno vsebuje kodo, ki se ne prevede
(CI run 35528386546 je padel pri `:app:compileDebugKotlin`). Popravek je pripravljen na lokalni veji
`fix/liquid-glass-compile` (commit `c2341d0`, iz `origin/master`), a iz sandboxa ga ni mogoče potisniti –
glej `za-github/NAVODILA.md` za dve poti (lokalni `git am fix.patch` ali urejanje v brskalniku).

## Kaj je bilo narobe (vse v `RoutineApp.kt`, morph prehod »Dodaj blok«, in `RoutineSheet.kt`)
| # | Napaka iz CI | Vzrok | Popravek |
|---|---|---|---|
| 1 | `boundsInWindow` unresolved | razširitvena funkcija ni bila uvožena | uvožen in uporabljen `boundsInRoot()` (isti koordinatni prostor kot okno morpha) |
| 2 | `animateFloat` napačna raba | to je API za `Transition`, ne za `LaunchedEffect` | suspend `animate(0f, 1f, tween(420)) { value, _ -> progress = value }` |
| 3 | `lerp` za `Float` se je razrešil v barvni `lerp` | manjkajoč uvoz | `androidx.compose.ui.util.lerp` |
| 4 | `Modifier.width(Int)` / `height(Int)` ne obstajata | (CI je zaradi omejitve 10 anotacij to napako skril) | izmerjena postavitev z `Modifier.layout { … }` v pikslih – skladno z invarianto projekta »brez offset-ov« (`check_presentation.py`) |
| 5 | `Velocity.consumeAll()` ne obstaja | izmišljen API | `onPostFling` vrne `available` (porabi ves preostanek flinga, list ne »potone«) |
| – | neuporabljen uvoz `Color` | – | odstranjen |

Vsebinsko se obnašanje ne spreminja: morph še vedno zraste iz izmerjenega položaja pilule v list,
stabilizator lista še vedno porabi samo preostanek *flinga* (počasen vlek za zapiranje lista deluje).

## Kako sem preveril
- **Lokalni prevod modula `:app`** z natanko istim razrednim naborom (71 knjižnic, `android.jar` 36,
  `R.jar`, `core.jar`, KSP-generirani Room viri) in Compose prevajalnikom 2.2.10, kot ju uporablja
  Gradle: **0 napak**, v spremenjenih datotekah **0 opozoril**. Modul `:core` se je prevedel že prej
  v okviru Gradle gradnje.
- **Statični CI gate-i** (`derive_palette --check`, `check_sqlite_integrity`, `check_presentation`,
  `check_contrast`): vsi zeleni.
- Testi (`app/src/test`, `app/src/androidTest`) ne uporabljajo nobenega spremenjenega API-ja; test
  `glassChromeOverlaysTheContentInsteadOfPushingItDown` še vedno najde `app-top-bar` in preverja
  prekrivanje, ki ga lebdeča vrstica ohranja.
- **Ni preverjeno lokalno** (sandbox ima 2 GB RAM, Gradle + R8 + emulator se ne izidejo):
  `lintDebug`, R8 release gradnja, emulatorski testi. To pokaže CI po push-u.

## Stanje in kaj potrebujem od tebe
- Commit `c2341d0` »Popravi prevajalne napake morph prehoda in stabilizatorja lista« je na lokalni
  veji `fix/liquid-glass-compile` (osnova `origin/master` = `c38514c`). Delovno drevo je čisto.
- **Push ni mogoč**: sandbox nima GitHub poverilnic in ta pogovor nima veje bota
  `arena-ai-coding-agent` (prejšnji pogovori so se začeli s pripetim repozitorijem, ta ne).
- Poti: `fix.patch` (en commit, uveljavi se na `master`) ali kopiranje končnih datotek iz `za-github/`
  v GitHubov urejevalnik – navodila v `za-github/NAVODILA.md`.

## Po zelenem CI-ju
- APK (release varianta, R8, podpisan z debug ključem):
  https://github.com/jakob611/MyDailyRoutine/releases/tag/debug-latest → datoteka `app-release.apk`
  (objavi jo build job PR-ja, brez merge-a).
- Ko sta oba job-a (build + device-tests) na popravku zelena in APK na telefonu potrdi lebdečo
  vrstico, steklene gumbe, morph in odsotnost trzanja, je popravek pripravljen za `master`.
