# Kako spraviti popravek na GitHub (stanje po merge-u PR #10)

`master` je zdaj na `c38514c` in vsebuje kodo, ki se ne prevede. Popravek je lokalno pripravljen na
veji `fix/liquid-glass-compile` (commit `c2341d0`, 2 datoteki, +22/−16), a iz sandboxa ga ni mogoče
potisniti. Izberi eno od poti – obe končata z zelenim CI-jem in svežim `app-release.apk`.

## Pot A – lokalni git (`fix.patch` iz delovnega prostora, 1 commit)
```
git fetch origin
git checkout -b fix/liquid-glass-compile origin/master
git am fix.patch
git push -u origin fix/liquid-glass-compile
```
Nato na GitHubu odpri PR `fix/liquid-glass-compile → master` (ali pa commit potisni kar na `master`:
`git checkout master && git pull && git am fix.patch && git push`).

## Pot B – GitHub v brskalniku (brez lokalnega gita)
V tej mapi sta **končni** različici obeh datotek. Za vsako:
1. odpri povezavo za urejanje spodaj,
2. označi vse (Ctrl+A) in prilepi celotno vsebino datoteke iz te mape,
3. »Commit changes…«.
   - najenostavneje: *Commit directly to the master branch* (master je že rdeč, popravek je preverjen), ali
   - čisteje: pri prvi datoteki izberi *Create a new branch for this commit and start a pull request*
     (ime `fix/liquid-glass-compile`), drugo datoteko pa uredi **na tej novi veji** (na strani datoteke
     zgoraj levo preklopi vejo, nato svinčnik).

| Datoteka tukaj | Cilj v repozitoriju |
|---|---|
| `RoutineApp.kt` | `app/src/main/java/com/example/mydailyroutine/app/presentation/RoutineApp.kt` |
| `RoutineSheet.kt` | `app/src/main/java/com/example/mydailyroutine/core/designsystem/components/RoutineSheet.kt` |

Povezavi za urejanje na `master`:
- https://github.com/jakob611/MyDailyRoutine/edit/master/app/src/main/java/com/example/mydailyroutine/app/presentation/RoutineApp.kt
- https://github.com/jakob611/MyDailyRoutine/edit/master/app/src/main/java/com/example/mydailyroutine/core/designsystem/components/RoutineSheet.kt

## Potem
Napiši mi »pushano« – CI spremljam prek javnega API-ja brez poverilnic, preverim anotacije, po potrebi
popravim in pošljem povezavo do `app-release.apk`
(https://github.com/jakob611/MyDailyRoutine/releases/tag/debug-latest).
